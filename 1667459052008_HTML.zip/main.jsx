let counter = 0;
function show() {
counter++;
const el= <p>{counter}</p>
ReactDom.render(
	el, document.getElementById('root'));
}
setInterval(show,1000);
